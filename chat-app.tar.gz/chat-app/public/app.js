const API_URL = '';
let socket = null;
let currentUser = null;
let currentChatUser = null;
let token = localStorage.getItem('token');

const userStr = localStorage.getItem('user');
if (userStr) {
  try {
    currentUser = JSON.parse(userStr);
  } catch (e) {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    token = null;
  }
}

if (token && currentUser) {
  showMain();
} else {
  showAuth();
}

function showAuth() {
  document.getElementById('auth-screen').classList.remove('hidden');
  document.getElementById('main-screen').classList.add('hidden');
  document.getElementById('chat-screen').classList.add('hidden');
}

function showMain() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('main-screen').classList.remove('hidden');
  document.getElementById('chat-screen').classList.add('hidden');
  loadUsers();
  connectSocket();
}

function showChat(userId, username) {
  currentChatUser = { id: parseInt(userId), username };
  document.getElementById('main-screen').classList.add('hidden');
  document.getElementById('chat-screen').classList.remove('hidden');
  
  document.getElementById('chat-username').textContent = username;
  document.getElementById('chat-avatar').textContent = username[0].toUpperCase();
  document.getElementById('chat-status').textContent = 'offline';
  
  loadMessages(userId);
}

function backToMain() {
  currentChatUser = null;
  document.getElementById('chat-screen').classList.add('hidden');
  document.getElementById('main-screen').classList.remove('hidden');
}

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  
  if (tab === 'login') {
    document.getElementById('login-form').classList.remove('hidden');
    document.getElementById('register-form').classList.add('hidden');
  } else {
    document.getElementById('login-form').classList.add('hidden');
    document.getElementById('register-form').classList.remove('hidden');
  }
}

async function login() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  
  if (!username || !password) {
    alert('Please fill in all fields');
    return;
  }
  
  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    
    const data = await res.json();
    if (data.token) {
      token = data.token;
      currentUser = { id: data.id, username: data.username };
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(currentUser));
      showMain();
    } else {
      alert(data.error || 'Login failed');
    }
  } catch (err) {
    alert('Network error');
  }
}

async function register() {
  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;
  
  if (!username || !password) {
    alert('Please fill in all fields');
    return;
  }
  
  try {
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    
    if (res.ok) {
      alert('Registered successfully! Please login.');
      switchTab('login');
      document.getElementById('register-username').value = '';
      document.getElementById('register-password').value = '';
    } else {
      const data = await res.json();
      alert(data.error || 'Registration failed');
    }
  } catch (err) {
    alert('Network error');
  }
}

function logout() {
  token = null;
  currentUser = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  if (socket) socket.disconnect();
  showAuth();
}

async function loadUsers() {
  try {
    const res = await fetch('/api/users', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (!res.ok) throw new Error('Failed to load users');
    
    const users = await res.json();
    const list = document.getElementById('contacts-list');
    list.innerHTML = '';
    
    if (users.length === 0) {
      list.innerHTML = '<div class="empty-state">No other users yet. Invite friends!</div>';
      return;
    }
    
    users.forEach(user => {
      const div = document.createElement('div');
      div.className = 'contact-item';
      div.onclick = () => showChat(user.id, user.username);
      div.innerHTML = `
        <div class="contact-avatar">${user.username[0].toUpperCase()}</div>
        <div class="contact-info">
          <div class="contact-name">${escapeHtml(user.username)}</div>
          <div class="contact-meta">Tap to chat</div>
        </div>
        <div class="contact-status" id="status-${user.id}"></div>
      `;
      list.appendChild(div);
    });
    
    document.getElementById('current-user').textContent = currentUser?.username || '';
  } catch (err) {
    console.error('Error loading users:', err);
  }
}

async function loadMessages(userId) {
  try {
    const res = await fetch(`/api/messages/${userId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (!res.ok) throw new Error('Failed to load messages');
    
    const messages = await res.json();
    const container = document.getElementById('messages-container');
    container.innerHTML = '';
    
    if (messages.length === 0) {
      container.innerHTML = '<div class="empty-state">No messages yet. Say hello!</div>';
    } else {
      messages.forEach(msg => appendMessage(msg));
    }
    
    container.scrollTop = container.scrollHeight;
  } catch (err) {
    console.error('Error loading messages:', err);
  }
}

function appendMessage(msg) {
  const container = document.getElementById('messages-container');
  
  const emptyState = container.querySelector('.empty-state');
  if (emptyState) emptyState.remove();
  
  const div = document.createElement('div');
  const isSent = msg.sender_id === currentUser?.id;
  div.className = `message ${isSent ? 'sent' : 'received'}`;
  
  const time = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  div.innerHTML = `
    ${escapeHtml(msg.content)}
    <div class="message-time">${time}</div>
  `;
  
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function connectSocket() {
  if (socket) return;
  
  socket = io();
  
  socket.on('connect', () => {
    socket.emit('authenticate', token);
  });
  
  socket.on('new_message', (msg) => {
    if (!currentChatUser) return;
    const relevant = (msg.sender_id === currentChatUser.id && msg.receiver_id === currentUser.id) ||
                     (msg.sender_id === currentUser.id && msg.receiver_id === currentChatUser.id);
    if (relevant) {
      appendMessage(msg);
    }
  });
  
  socket.on('user_online', ({ userId }) => {
    const el = document.getElementById(`status-${userId}`);
    if (el) el.classList.add('online');
    if (currentChatUser && currentChatUser.id === userId) {
      document.getElementById('chat-status').textContent = 'online';
    }
  });
  
  socket.on('user_offline', ({ userId }) => {
    const el = document.getElementById(`status-${userId}`);
    if (el) el.classList.remove('online');
    if (currentChatUser && currentChatUser.id === userId) {
      document.getElementById('chat-status').textContent = 'offline';
    }
  });
}

function sendMessage() {
  const input = document.getElementById('message-input');
  const content = input.value.trim();
  
  if (!content || !currentChatUser) return;
  
  if (!socket) {
    alert('Not connected');
    return;
  }
  
  socket.emit('send_message', {
    receiverId: currentChatUser.id,
    content
  });
  
  input.value = '';
  input.focus();
}

document.getElementById('message-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendMessage();
});
