const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Database setup
const db = new sqlite3.Database('./chat.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id)
  )`);
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  
  try {
    const decoded = jwt.verify(token, 'secret_key');
    req.user = decoded;
    next();
  } catch {
    res.status(403).json({ error: 'Invalid token' });
  }
};

app.post('/api/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  
  const hashed = bcrypt.hashSync(password, 10);
  db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashed], function(err) {
    if (err) return res.status(400).json({ error: 'Username exists' });
    res.json({ id: this.lastID, username });
  });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err || !user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, username: user.username }, 'secret_key');
    res.json({ token, username: user.username, id: user.id });
  });
});

app.get('/api/users', authenticate, (req, res) => {
  db.all('SELECT id, username, created_at FROM users WHERE id != ?', [req.user.id], (err, users) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(users);
  });
});

app.get('/api/messages/:userId', authenticate, (req, res) => {
  const otherId = req.params.userId;
  const myId = req.user.id;
  
  db.all(
    `SELECT m.*, u.username as sender_name 
     FROM messages m 
     JOIN users u ON m.sender_id = u.id 
     WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
     ORDER BY m.created_at ASC`,
    [myId, otherId, otherId, myId],
    (err, messages) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(messages);
    }
  );
});

const onlineUsers = new Map();

io.on('connection', (socket) => {
  let currentUser = null;
  
  socket.on('authenticate', (token) => {
    try {
      const decoded = jwt.verify(token, 'secret_key');
      currentUser = decoded;
      onlineUsers.set(decoded.id, { socketId: socket.id, username: decoded.username });
      socket.broadcast.emit('user_online', { userId: decoded.id, username: decoded.username });
    } catch (err) {
      console.log('Invalid socket auth');
    }
  });
  
  socket.on('send_message', (data) => {
    if (!currentUser) return;
    
    const { receiverId, content } = data;
    if (!content || !receiverId) return;
    
    db.run(
      'INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)',
      [currentUser.id, receiverId, content],
      function(err) {
        if (err) return;
        
        const message = {
          id: this.lastID,
          sender_id: currentUser.id,
          receiver_id: parseInt(receiverId),
          content,
          sender_name: currentUser.username,
          created_at: new Date().toISOString()
        };
        
        socket.emit('new_message', message);
        
        const receiver = onlineUsers.get(parseInt(receiverId));
        if (receiver) {
          io.to(receiver.socketId).emit('new_message', message);
        }
      }
    );
  });
  
  socket.on('disconnect', () => {
    if (currentUser) {
      onlineUsers.delete(currentUser.id);
      socket.broadcast.emit('user_offline', { userId: currentUser.id });
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
