# ChatApp

A real-time mobile chat application inspired by WhatsApp. Built with Node.js, Express, Socket.io, and SQLite.

## Features

- **User Registration & Login** — Secure accounts with password hashing
- **Real-time Messaging** — Instant message delivery via WebSockets
- **Message History** — All conversations saved in SQLite database
- **Online/Offline Status** — See when contacts are online
- **Mobile-First Design** — Works perfectly on phones and desktop

## Quick Start (Local)

```bash
npm install
npm start
```

Then open `http://localhost:3000` in your browser.

## Deploy to Render.com (Free Permanent URL)

1. **Push to GitHub**
   - Create a new repo on GitHub
   - Upload these files (server.js, package.json, public/ folder)

2. **Create Web Service on Render**
   - Go to [render.com](https://render.com) and sign up (free, no credit card)
   - Click **"New +"** → **"Web Service"**
   - Connect your GitHub repo

3. **Configure Settings**
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free

4. **Deploy**
   - Click "Create Web Service"
   - Render gives you a permanent URL like `https://chat-app-xxx.onrender.com`

## Project Structure

```
chat-app/
├── server.js          # Backend API + Socket.io server
├── package.json       # Dependencies
└── public/
    ├── index.html     # App UI
    ├── style.css      # WhatsApp-style mobile design
    └── app.js         # Frontend logic
```

## Tech Stack

- **Backend:** Node.js, Express, Socket.io, SQLite
- **Frontend:** Vanilla JavaScript (no build step needed)
- **Security:** bcryptjs (password hashing), JWT (authentication)

## Customization

You have **full control** to modify:
- Colors in `public/style.css` (change the green theme!)
- Features in `server.js` (add group chats, file sharing, etc.)
- UI in `public/index.html` (add emojis, voice messages, etc.)
